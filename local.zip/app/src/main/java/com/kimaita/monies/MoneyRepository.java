package com.kimaita.monies;

import android.app.Application;

import androidx.lifecycle.LiveData;

public class MoneyRepository {

    private final ExpenseDao mExpenseDao;
    private final LiveData<Expense> mAllExpenses;


    MoneyRepository(Application application) {
        MoneyRoomDatabase db = MoneyRoomDatabase.getDatabase(application);
        mExpenseDao = db.ExpenseDao();
        mAllExpenses = mExpenseDao.getAllExpenses();
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    LiveData<Expense> getAllExpenses() {
        return mAllExpenses;
    }

    /*public void insert (Word word) {
        new insertAsyncTask(mWordDao).execute(word);
    }

    private static class insertAsyncTask extends AsyncTask<Word, Void, Void> {

        private WordDao mAsyncTaskDao;

        insertAsyncTask(WordDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Word... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }
    */
    // You must call this on a non-UI thread or your app will throw an exception. Room ensures
    // that you're not doing any long running operations on the main thread, blocking the UI.
    //add expenses from user input.
    void insert(Expense Expense) {
            MoneyRoomDatabase.databaseWriteExecutor.execute(() -> {
            mExpenseDao.insert(Expense);
        });
    }
    //add expenses from read M-PESA messages.
    void addMpesaExpense(Expense Expense) {
            MoneyRoomDatabase.databaseWriteExecutor.execute(() -> {
            mExpenseDao.addMpesaExpense(Expense);
        });
    }
}