package com.kimaita.monies;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class NewExpenseActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "com.kimaita.monies.REPLY";
    private static final int TYPE_DATETIME_VARIATION_NORMAL = 4;
    private static final int SMS_PERMISSION_CODE = 1;
    private final ArrayList<Message> messageList = new ArrayList<>();

    private EditText mEditAmtView;
    private EditText mEditUseView;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onStart() {
        super.onStart();
        checkAndRequestPermissions();
        getAllMessage();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_expense);
        mEditAmtView = findViewById(R.id.edit_amount);
        mEditUseView = findViewById(R.id.edit_use);
        EditText mEditDayView = findViewById(R.id.edit_time);
        mEditDayView.setInputType(TYPE_DATETIME_VARIATION_NORMAL);
        final Button button = findViewById(R.id.button_save);

        button.setOnClickListener(view -> {
            Intent replyIntent = new Intent();
            if (TextUtils.isEmpty(mEditAmtView.getText())) {
                setResult(RESULT_CANCELED, replyIntent);
            } else {
                String Use = mEditUseView.getText().toString();
                String Amount = mEditAmtView.getText().toString();
                String Day = mEditAmtView.getText().toString();
                //Here we use a Bundle object to add new name and values pairs
                Bundle bundle = new Bundle();
                bundle.putString("USE", Use);
                bundle.putDouble("AMOUNT", Double.parseDouble(Amount));
                bundle.putLong("DAY", Long.parseLong(Day));
                replyIntent.putExtras(bundle);
                setResult(RESULT_OK, replyIntent);
            }
            finish();
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public ArrayList<Message> getAllMessage() {
        Uri inbox = Uri.parse("content://sms/inbox");
        ContentResolver cr = MainActivity.this.getContentResolver();
        //This defines a one-element String array to contain the selection argument.
        String[] selectionArgs = {""};
        String searchString = "MPESA";
        String selectionClause = Telephony.Sms.ADDRESS + " = ?";
        selectionArgs[0] = searchString;

        Cursor c = cr.query(inbox, null, selectionClause, selectionArgs, null,  null);
        int totalSMS = c.getCount();

        //String substr = mysourcestring.substring(10, 19);

        if (c.moveToFirst()) {
            for (int i = 0; i < totalSMS; i++) {
                if (!c.getString(c.getColumnIndexOrThrow("body")).substring(11, 20).equals("Confirmed")){
                    c.moveToNext();
                }
                else {
                    Message objMessage = new Message();
                    objMessage.setId(c.getString(c.getColumnIndexOrThrow("_id")));
                    objMessage.setAddress(c.getString(c.getColumnIndexOrThrow("address")));
                    objMessage.setMsg(c.getString(c.getColumnIndexOrThrow("body")));
                    messageList.add(objMessage);
                    c.moveToNext();
                }
            }
        }
        else {
            // throw new RuntimeException("You have no SMS");
            Toast.makeText(this, "You have no SMS", Toast.LENGTH_LONG).show();
        }
        c.close();

        return messageList;
    }

    //String substr=mysourcestring.substring(mysourcestring.indexOf("characterValue"));
    String s = "123dance456";
    String[] split = s.split("dance");
    String firstSubString = split[0];
    String secondSubString = split[1];
    public Expense expenseMessages(Message message){


    }

    private void checkAndRequestPermissions()
    {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "You have already granted this permission!",
                    Toast.LENGTH_SHORT).show();
        } else {
            requestStoragePermission();
        }
    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed to read M-PESA MESSAGES")
                    .setPositiveButton("Proceed", (dialog, which) -> ActivityCompat.requestPermissions(NewExpenseActivity.this, new String[] {Manifest.permission.READ_SMS}, SMS_PERMISSION_CODE))
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, SMS_PERMISSION_CODE);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == SMS_PERMISSION_CODE)  {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}