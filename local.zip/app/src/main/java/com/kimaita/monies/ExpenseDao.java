package com.kimaita.monies;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Expense expense);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void addMpesaExpense(Message message);

    @Query("DELETE FROM expenses")
    void deleteAll();

    @Query("SELECT * from word_table LIMIT 1")
    Word[] getAnyWord();

    @Query("SELECT amt, day, use FROM expenses")
    LiveData<List<Expense>> getAllExpenses();

    @Query("SELECT amt, day, use FROM expenses WHERE day = :day")
    LiveData<List<Expense>> getDayExpenses(int day);

    @Query("SELECT amt, day FROM expenses WHERE day = :day ORDER BY day ASC")
    LiveData<List<Expense>> getWeekExpenses(int day);

    @Query("SELECT amt, day FROM expenses WHERE day = :day ORDER BY day ASC")
    LiveData<List<Expense>> getMonthExpenses(int day);

    @Query("SELECT amt, day FROM expenses WHERE day = :day ORDER BY day ASC")
    LiveData<List<Expense>> getYearExpenses(int day);

    @Query("SELECT use, sum(amt) FROM expenses WHERE use MATCH :use GROUP BY use ORDER BY amt ASC")
    LiveData<List<Expense>> getActivityExpenditure(String use);
}