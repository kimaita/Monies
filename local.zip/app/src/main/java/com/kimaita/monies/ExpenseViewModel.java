package com.kimaita.monies;

import android.app.Application;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class ExpenseViewModel extends AndroidViewModel {

    private final MoneyRepository mRepository;

    private final LiveData<List<Expense>> mAllExpenses;

    public ExpenseViewModel (Application application) {
        super(application);
        mRepository = new MoneyRepository(application);
        mAllExpenses = mRepository.getAllExpenses();
    }

    LiveData<List<Expense>> getAllExpenses() { return mAllExpenses; }

    public void insert(Expense expense) { mRepository.insert(expense); }
}