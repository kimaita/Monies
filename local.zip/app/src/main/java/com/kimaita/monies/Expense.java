package com.kimaita.monies;

import java.sql.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "expenses", indices = {@Index(value = {"use"})})
public class Expense {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    @ColumnInfo(name = "amt")
    public double amount;

    public String use;

    @NonNull
    @ColumnInfo(name = "day")
    public Date forDay;


    public Expense(int id, double amount, String use) {
        this.id = id;
        this.amount = amount;
        this.use = use;
    }
    public void setForDay(Date forDay) {
        this.forDay = forDay;
    }

    public int getId() {
        return id;
    }
    public double getAmount() {
        return amount;
    }
    public String getUse() {
        return use;
    }
    public Date getForDay() {
        return forDay;
    }

}
