package com.kimaita.monies;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.sql.Date;

import androidx.recyclerview.widget.RecyclerView;

class ExpenseViewHolder extends RecyclerView.ViewHolder {
    private final TextView amtItemView;
    private final TextView dayItemView;
    private final TextView useItemView;

    private ExpenseViewHolder(View itemView) {
        super(itemView);
        amtItemView = itemView.findViewById(R.id.textViewAmt);
        dayItemView = itemView.findViewById(R.id.textViewTime);
        useItemView = itemView.findViewById(R.id.textViewUse);
    }

    public void bind(int Amount, String use, CharSequence Day) {
        amtItemView.setText(Amount);
        dayItemView.setText(Day);
        useItemView.setText(use);
    }

    static ExpenseViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerviewitem, parent, false);
        return new ExpenseViewHolder(view);
    }
}